package com.example.alsy.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;

import com.example.adsdk.out.OADInterstitial;

public class Main2Activity extends AppCompatActivity {
    OADInterstitial oadInterstitial;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        oadInterstitial = new OADInterstitial(this);
        oadInterstitial.LoadInterstitial();

        findViewById(R.id.haha).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (oadInterstitial.isLoaded())
                    oadInterstitial.show();
            }
        });
    }

}
