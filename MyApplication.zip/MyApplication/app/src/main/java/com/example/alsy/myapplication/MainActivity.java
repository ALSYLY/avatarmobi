package com.example.alsy.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.example.adsdk.models.ads.interfaces.ibanner.ADBannerListener;
import com.example.adsdk.models.ads.interfaces.iinterstitial.ADInterstitialListener;
import com.example.adsdk.models.ads.interfaces.ivideo.ADRewardItem;
import com.example.adsdk.models.ads.interfaces.ivideo.ADRewardedVideoListener;
import com.example.adsdk.out.OADBanner;
import com.example.adsdk.out.OADInterstitial;
import com.example.adsdk.out.OADVideo;
import com.example.adsdk.out.SmartAds;


/**
 * A login screen that offers login via email/password.
 */
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        //初始化
        SmartAds.init(this, "1", "1",true);
        final ViewGroup container = findViewById(R.id.container);
        findViewById(R.id.banner).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                OADBanner oadBanner = new OADBanner(MainActivity.this);
                oadBanner.LoadBanner(container);
                oadBanner.setAdBannerListener(new ADBannerListener() {
                    @Override
                    public void onAdLeftApplication(String var1) {

                    }

                    @Override
                    public void onBannerLoaded(String var1, View var2) {

                    }

                    @Override
                    public void onBannerUnloaded(String var1) {

                    }

                    @Override
                    public void onBannerShow(String var1) {


                    }

                    @Override
                    public void onBannerClick(String var1) {


                    }

                    @Override
                    public void onBannerHide(String var1) {



                    }

                    @Override
                    public void onBannerError(String var1) {

                    }

                    @Override
                    public void onBannerClosed(String var1) {

                    }
                });

            }
        });

        final OADInterstitial oadInterstitial = new OADInterstitial(this);;
        final Button ib = findViewById(R.id.interstitial);

        ib.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (!oadInterstitial .isLoaded()) return;

                oadInterstitial .show();
                oadInterstitial.setAdInterstitialListener(new ADInterstitialListener() {
                    @Override
                    public void onAdClosed() {
                    }

                    @Override
                    public void onAdFailedToLoad(int var1) {

                    }

                    @Override
                    public void onAdLeftApplication() {

                    }

                    @Override
                    public void onAdOpened() {
                    }

                    @Override
                    public void onAdLoaded() {
                    }

                    @Override
                    public void onAdClicked() {
                    }

                    @Override
                    public void onAdImpression() {
                    }
                });
            }
        });
        findViewById(R.id.interstitial_load).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                oadInterstitial.LoadInterstitial();

            }
        });

        final OADVideo oadVideo = new OADVideo(this);
        final Button vb = findViewById(R.id.video);
        vb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!oadVideo.isLoaded()) return;

                oadVideo.show();
                oadVideo.setRewardedVideoAdListener(new ADRewardedVideoListener() {
                    @Override
                    public void onRewardedVideoAdLoaded() {

                    }

                    @Override
                    public void onRewardedVideoAdOpened() {

                    }

                    @Override
                    public void onRewardedVideoStarted() {

                    }

                    @Override
                    public void onRewardedVideoAdClosed() {

                    }

                    @Override
                    public void onRewarded(ADRewardItem var1) {

                    }

                    @Override
                    public void onRewardedVideoAdLeftApplication() {

                    }

                    @Override
                    public void onRewardedVideoAdFailedToLoad(int var1) {

                    }

                    @Override
                    public void onRewardedVideoCompleted() {

                    }
                });
            }
        });
        findViewById(R.id.video_load).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                oadVideo.loadVideo();
            }
        });
        findViewById(R.id.en).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            startActivity(new Intent(MainActivity.this, Main2Activity.class));

            }
        });

    }

    @Override
    protected void onStart() {
        Log.e("", "OnStart finished!!!!!");
        super.onStart();
        SmartAds.onStart(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.e("", "onResume finished!!!!!");
        SmartAds.onResume(this);
    }

    @Override
    protected void onStop() {
        Log.e("", "onStop finished!!!!!");
        super.onStop();
        SmartAds.onStop(this);
    }

    @Override
    protected void onPause() {
        Log.e("", "onPause finished!!!!!");
        super.onPause();
        SmartAds.onPause(this);
    }

    @Override
    protected void onDestroy() {
        Log.e("", "onDestroy finished!!!!!");
        super.onDestroy();
        SmartAds.onDestroy(this);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        SmartAds.onBackPressed(this);
    }
}

